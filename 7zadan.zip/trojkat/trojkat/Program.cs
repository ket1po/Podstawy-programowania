﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trojkat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //zad1();
            //zad2();
            //zad3();
            //zad4();
            //zad5();
            //zad6();
            //zad7();
        }
        static void zad1()
        {
            double a = 0;
            Console.WriteLine("Wprowadź  bok a: ");
             a = Convert.ToInt32(Console.ReadLine());
            double b = 0;
            Console.WriteLine("Wprowadź bok b: ");
             b = Convert.ToInt32(Console.ReadLine()) ;
            Console.WriteLine(a * b);
            Console.ReadLine();
        }


        static void zad2()
        {
            Console.WriteLine(Math.Round(Math.PI,5));
        }

        static void zad3()
        {
            double a = Math.Sqrt(Math.PI);
            Console.WriteLine(Math.Round(a,2));
        }


        static void zad4()
        {
            double v = 0;
            double r = 0;
            double p = Math.PI;
            Console.WriteLine("Wprowadz wartosc r: ");
            r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(v=4.0/3.0 * p * Math.Pow(r,3));

        }


        static void zad5()
        {
            
            int a = 37;
            int b = 11;
            Console.WriteLine(a / b);
            
        }

        static void zad6()
        {
            double a = 37;
            double b = 11;
            Console.WriteLine(a % b);
        }

        static void zad7()
        {
            double x = 0;
            Console.WriteLine("Wprowadź x: ");
            x = Convert.ToInt32(Console.ReadLine());
            double y = 0;
            Console.WriteLine("Wprowadź y: ");
            y = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(Math.Round(x + y, 2));
            Console.WriteLine(Math.Round(x - y, 2));
            Console.WriteLine(Math.Round(x * y, 2));
            Console.WriteLine(Math.Round(x / y, 2));

        }
    }

}




